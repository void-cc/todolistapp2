from sqlalchemy import create_engine
import database_interactions.databasemodels as dbm
from sqlalchemy.orm import Session


engine = create_engine('sqlite+pysqlite:///..todo.db', echo=True)
dbm.Base.metadata.create_all(engine)


sessiondatabase = Session(engine)